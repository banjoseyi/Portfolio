
import React from 'react';
import { PROJECTS } from '../constants';

const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-32 px-8 md:px-24 bg-slate-950/80">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-16 flex items-center">
          Selected Projects
          <span className="ml-6 h-px flex-1 bg-gradient-to-r from-teal-500/50 to-transparent"></span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {PROJECTS.map((project) => (
            <div 
              key={project.id} 
              className="group relative bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-teal-500/30 transition-all duration-500"
            >
              <div className="aspect-video overflow-hidden">
                <img 
                  src={project.imageUrl} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>
              <div className="p-8">
                <div className="flex gap-2 mb-4">
                  {project.tech.map(t => (
                    <span key={t} className="text-[10px] text-teal-400 border border-teal-500/20 px-2 py-0.5 rounded-full uppercase tracking-tighter">
                      {t}
                    </span>
                  ))}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{project.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed mb-6">
                  {project.description}
                </p>
                <a 
                  href={project.link}
                  className="text-teal-400 text-sm font-semibold hover:text-teal-300 inline-flex items-center gap-2 group-hover:translate-x-2 transition-transform"
                >
                  View Case Study
                  <span>→</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
