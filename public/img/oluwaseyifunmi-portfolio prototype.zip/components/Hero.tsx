
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center px-8 md:px-24 overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 nebula-bg -z-10"></div>
      
      <div className="max-w-3xl animate-fadeIn">
        <div className="text-teal-400 font-medium mb-6 tracking-widest text-lg">
          &lt; Hello &gt;
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-8 leading-tight">
          I'm Oluwaseyifunmi
        </h1>
        
        <p className="text-xl md:text-2xl text-slate-300 font-light mb-12 max-w-xl">
          Frontend Developer building modern web experiences.
        </p>
        
        <a 
          href="#contact"
          className="inline-block border border-teal-500/50 text-white px-10 py-3.5 rounded-full hover:bg-teal-500/10 transition-all duration-300 text-lg font-medium glow-teal"
        >
          Contact me
        </a>
      </div>

      {/* Decorative Star Particles */}
      <div className="absolute inset-0 pointer-events-none opacity-50">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i}
            className="absolute rounded-full bg-white animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 3}px`,
              height: `${Math.random() * 3}px`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 5}s`
            }}
          />
        ))}
      </div>
    </section>
  );
};

export default Hero;
