
import React, { useState } from 'react';
import { generateProjectIdeas } from '../services/geminiService';
import { SuggestedProject } from '../types';

const AiBrainstormer: React.FC = () => {
  const [skills, setSkills] = useState('');
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState<SuggestedProject[]>([]);

  const handleBrainstorm = async () => {
    if (!skills.trim()) return;
    setLoading(true);
    try {
      const result = await generateProjectIdeas(skills);
      setIdeas(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-24 px-8 md:px-24 bg-[#0a0f1e]">
      <div className="max-w-5xl mx-auto bg-gradient-to-br from-slate-900 to-slate-950 p-8 md:p-12 rounded-3xl border border-slate-800 relative overflow-hidden">
        {/* Decor */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl"></div>
        
        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-white mb-4">AI Project Brainstormer</h2>
          <p className="text-slate-400 mb-8 max-w-2xl">
            Input your tech stack, and I'll have Gemini generate unique, high-end project ideas to help you level up your portfolio.
          </p>

          <div className="flex flex-col md:flex-row gap-4 mb-12">
            <input 
              type="text" 
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              placeholder="e.g. React, Tailwind, Three.js, Node.js"
              className="flex-1 bg-slate-800/50 border border-slate-700 rounded-xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/50 transition-all"
            />
            <button 
              onClick={handleBrainstorm}
              disabled={loading || !skills}
              className="bg-teal-500 hover:bg-teal-600 disabled:bg-slate-700 text-slate-950 font-bold px-8 py-4 rounded-xl transition-all flex items-center justify-center gap-2 min-w-[160px]"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                'Brainstorm'
              )}
            </button>
          </div>

          {ideas.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
              {ideas.map((idea, idx) => (
                <div key={idx} className="bg-slate-800/30 p-6 rounded-2xl border border-slate-700 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                      idea.complexity === 'Advanced' ? 'bg-red-500/20 text-red-400' : 
                      idea.complexity === 'Intermediate' ? 'bg-yellow-500/20 text-yellow-400' : 
                      'bg-green-500/20 text-green-400'
                    }`}>
                      {idea.complexity}
                    </span>
                  </div>
                  <h4 className="text-white font-bold text-lg mb-2">{idea.title}</h4>
                  <p className="text-slate-400 text-xs mb-4 flex-1 leading-relaxed">{idea.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {idea.techStack.map(t => (
                      <span key={t} className="text-[9px] bg-slate-700/50 text-slate-300 px-1.5 py-0.5 rounded">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default AiBrainstormer;
