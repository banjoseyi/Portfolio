
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-32 px-8 md:px-24 bg-slate-950">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-20">
        <div className="w-full md:w-1/2 relative group">
          <div className="absolute inset-0 border-2 border-teal-500/20 rounded-3xl translate-x-4 translate-y-4 group-hover:translate-x-2 group-hover:translate-y-2 transition-all"></div>
          <img 
            src="https://picsum.photos/seed/olu/800/1000" 
            alt="Profile" 
            className="relative w-full aspect-[4/5] object-cover rounded-3xl"
          />
        </div>
        
        <div className="w-full md:w-1/2">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-10 leading-tight">
            Engineering digital <br/>
            <span className="text-teal-400">experiences with intent.</span>
          </h2>
          
          <div className="space-y-6 text-slate-400 text-lg font-light leading-relaxed">
            <p>
              I am a frontend developer based in the future, specialized in building visually immersive and performant web applications. My approach combines technical rigor with a passion for aesthetic elegance.
            </p>
            <p>
              Over the past few years, I've focused on mastering modern frameworks and pushing the boundaries of what's possible in the browser, from complex data visualizations to AI-integrated workflows.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-8">
            <div>
              <h4 className="text-white font-bold mb-4 uppercase tracking-widest text-sm">Capabilities</h4>
              <ul className="text-slate-400 space-y-2 text-sm">
                <li>UI Architecture</li>
                <li>Design Systems</li>
                <li>Creative Coding</li>
                <li>AI Integration</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4 uppercase tracking-widest text-sm">Main Stack</h4>
              <ul className="text-slate-400 space-y-2 text-sm">
                <li>React / TypeScript</li>
                <li>Tailwind / Framer</li>
                <li>Three.js / Canvas</li>
                <li>Gemini / LLMs</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
