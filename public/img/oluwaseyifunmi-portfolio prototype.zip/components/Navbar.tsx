
import React from 'react';

const Navbar: React.FC = () => {
  const navItems = ['ABOUT', 'PORTFOLIO', 'CONTACT'];

  return (
    <nav className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-8 py-8 md:px-16 transition-all duration-300">
      <div className="text-xl font-bold text-white tracking-wide">
        Oluwaseyifunmi
      </div>
      <div className="hidden md:flex space-x-12">
        {navItems.map((item) => (
          <a
            key={item}
            href={`#${item.toLowerCase()}`}
            className="text-xs font-semibold text-slate-300 hover:text-teal-400 transition-colors tracking-[0.2em]"
          >
            {item}
          </a>
        ))}
      </div>
      {/* Mobile Menu Placeholder - simple hamburger would go here */}
      <div className="md:hidden text-white">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
      </div>
    </nav>
  );
};

export default Navbar;
