
import React from 'react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-32 px-8 md:px-24 bg-slate-950">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">Let's build something <br/> extraordinary together.</h2>
        <p className="text-slate-400 text-xl mb-16 font-light">
          Currently available for high-end freelance opportunities and collaborative projects.
        </p>

        <form className="text-left space-y-8 max-w-2xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest text-slate-500 font-bold ml-1">Name</label>
              <input type="text" className="w-full bg-transparent border-b border-slate-800 py-3 text-white focus:outline-none focus:border-teal-500 transition-colors" placeholder="John Doe" />
            </div>
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest text-slate-500 font-bold ml-1">Email</label>
              <input type="email" className="w-full bg-transparent border-b border-slate-800 py-3 text-white focus:outline-none focus:border-teal-500 transition-colors" placeholder="john@example.com" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs uppercase tracking-widest text-slate-500 font-bold ml-1">Message</label>
            <textarea rows={4} className="w-full bg-transparent border-b border-slate-800 py-3 text-white focus:outline-none focus:border-teal-500 transition-colors resize-none" placeholder="Tell me about your project..."></textarea>
          </div>
          
          <button className="w-full md:w-auto bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-12 py-5 rounded-full transition-all duration-300 transform hover:-translate-y-1">
            Send Inquiry
          </button>
        </form>

        <div className="mt-24 pt-12 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center text-slate-500 text-sm">
          <div>© 2024 Oluwaseyifunmi. All rights reserved.</div>
          <div className="flex gap-8 mt-6 md:mt-0">
            <a href="#" className="hover:text-teal-400 transition-colors">LinkedIn</a>
            <a href="#" className="hover:text-teal-400 transition-colors">GitHub</a>
            <a href="#" className="hover:text-teal-400 transition-colors">Twitter</a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
