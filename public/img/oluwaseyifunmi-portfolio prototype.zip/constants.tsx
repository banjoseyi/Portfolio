
import { Project } from './types';

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Quantum Dashboard',
    description: 'A high-performance data visualization platform using WebGL and D3.js for real-time analytics.',
    tech: ['React', 'Three.js', 'D3.js', 'Tailwind'],
    imageUrl: 'https://picsum.photos/seed/quantum/800/600',
    link: '#'
  },
  {
    id: '2',
    title: 'Ethereal OS',
    description: 'A concept browser-based operating system with a glassmorphism interface and integrated AI tools.',
    tech: ['TypeScript', 'Framer Motion', 'Vite'],
    imageUrl: 'https://picsum.photos/seed/ethereal/800/600',
    link: '#'
  },
  {
    id: '3',
    title: 'Aura Social',
    description: 'A decentralized social network prioritizing user privacy and aesthetic minimalism.',
    tech: ['Next.js', 'Solidity', 'IPFS'],
    imageUrl: 'https://picsum.photos/seed/aura/800/600',
    link: '#'
  }
];
