
export interface Project {
  id: string;
  title: string;
  description: string;
  tech: string[];
  imageUrl: string;
  link: string;
}

export interface SuggestedProject {
  title: string;
  description: string;
  complexity: 'Beginner' | 'Intermediate' | 'Advanced';
  techStack: string[];
}
