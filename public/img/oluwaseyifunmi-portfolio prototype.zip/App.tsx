
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Portfolio from './components/Portfolio';
import AiBrainstormer from './components/AiBrainstormer';
import Contact from './components/Contact';

const App: React.FC = () => {
  return (
    <div className="bg-slate-950 min-h-screen text-slate-200 selection:bg-teal-500/30">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Portfolio />
        <AiBrainstormer />
        <Contact />
      </main>
    </div>
  );
};

export default App;
